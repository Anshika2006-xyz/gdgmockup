export interface Game {
  id: string
  title: string
  genre: string
  rating: number
  price: number | null
  image: string
  description: string
  tags: string[]
  releaseYear: number
  platform: string[]
  playerCount: string
  progress?: number
  lastPlayed?: string
  trophies?: { earned: number; total: number }
}

export interface Friend {
  id: string
  name: string
  avatar: string
  status: "online" | "in-game" | "offline" | "away"
  currentGame?: string
  level: number
}

export interface Trophy {
  id: string
  name: string
  description: string
  rarity: "common" | "uncommon" | "rare" | "ultra-rare" | "legendary"
  game: string
  earned: boolean
  earnedDate?: string
  icon: string
}

export interface Lobby {
  id: string
  name: string
  game: string
  host: string
  members: number
  maxMembers: number
  status: "waiting" | "in-game" | "full"
}

export const games: Game[] = [
  {
    id: "1",
    title: "Astral Horizon",
    genre: "Action RPG",
    rating: 4.8,
    price: null,
    image: "/images/game-1.jpg",
    description: "Explore a vast open world filled with mythic creatures, ancient ruins, and epic boss battles. Your journey across the astral planes awaits.",
    tags: ["Open World", "RPG", "Fantasy", "Single Player"],
    releaseYear: 2025,
    platform: ["PS5"],
    playerCount: "1 Player",
    progress: 72,
    lastPlayed: "2 hours ago",
    trophies: { earned: 34, total: 52 },
  },
  {
    id: "2",
    title: "Velocity Strike",
    genre: "FPS",
    rating: 4.5,
    price: 59.99,
    image: "/images/game-2.jpg",
    description: "Fast-paced competitive shooter with ranked modes, clan wars, and seasonal content. Dominate the arena.",
    tags: ["Multiplayer", "FPS", "Competitive", "Esports"],
    releaseYear: 2025,
    platform: ["PS5", "PS4"],
    playerCount: "1-64 Players",
    progress: 45,
    lastPlayed: "Yesterday",
    trophies: { earned: 18, total: 40 },
  },
  {
    id: "3",
    title: "Neon Drift",
    genre: "Racing",
    rating: 4.3,
    price: 39.99,
    image: "/images/game-3.jpg",
    description: "Cyberpunk racing through neon-lit megacities. Customize your ride, challenge rivals, and own the streets.",
    tags: ["Racing", "Cyberpunk", "Multiplayer", "Arcade"],
    releaseYear: 2024,
    platform: ["PS5"],
    playerCount: "1-8 Players",
    progress: 30,
    lastPlayed: "3 days ago",
    trophies: { earned: 12, total: 35 },
  },
  {
    id: "4",
    title: "The Last Chronicle",
    genre: "Story Adventure",
    rating: 4.9,
    price: 69.99,
    image: "/images/game-4.jpg",
    description: "A cinematic masterpiece. Navigate a world torn by war, making choices that shape the fate of civilizations.",
    tags: ["Story Rich", "Adventure", "Single Player", "Cinematic"],
    releaseYear: 2025,
    platform: ["PS5"],
    playerCount: "1 Player",
  },
  {
    id: "5",
    title: "Phantom Realms Online",
    genre: "MMORPG",
    rating: 4.2,
    price: null,
    image: "/images/game-5.jpg",
    description: "A massive online world with dungeons, raids, and an ever-expanding storyline. Free to play with PS Plus benefits.",
    tags: ["MMO", "RPG", "Online", "Free to Play"],
    releaseYear: 2024,
    platform: ["PS5", "PS4"],
    playerCount: "Massively Multiplayer",
  },
  {
    id: "6",
    title: "Iron Colossus",
    genre: "Action",
    rating: 4.6,
    price: 49.99,
    image: "/images/game-6.jpg",
    description: "Command towering mechs in intense battles across war-torn landscapes. Build, upgrade, and dominate.",
    tags: ["Action", "Mech", "Strategy", "Multiplayer"],
    releaseYear: 2025,
    platform: ["PS5"],
    playerCount: "1-4 Players",
  },
  {
    id: "7",
    title: "Shadow Protocol",
    genre: "Stealth",
    rating: 4.7,
    price: 59.99,
    image: "/images/game-7.jpg",
    description: "Infiltrate enemy strongholds, hack security systems, and eliminate targets in this gripping stealth thriller.",
    tags: ["Stealth", "Thriller", "Single Player", "Tactical"],
    releaseYear: 2025,
    platform: ["PS5"],
    playerCount: "1 Player",
  },
  {
    id: "8",
    title: "Celestial Odyssey",
    genre: "Space Exploration",
    rating: 4.4,
    price: 49.99,
    image: "/images/game-8.jpg",
    description: "Chart unexplored galaxies, build colonies on alien worlds, and uncover the mysteries of the cosmos.",
    tags: ["Space", "Exploration", "Sandbox", "Co-op"],
    releaseYear: 2024,
    platform: ["PS5", "PS4"],
    playerCount: "1-4 Players",
  },
]

export const friends: Friend[] = [
  { id: "1", name: "ShadowKnight_99", avatar: "/images/avatar-1.jpg", status: "in-game", currentGame: "Astral Horizon", level: 42 },
  { id: "2", name: "NeonRacer", avatar: "/images/avatar-2.jpg", status: "online", level: 38 },
  { id: "3", name: "PhantomBlade", avatar: "/images/avatar-3.jpg", status: "in-game", currentGame: "Velocity Strike", level: 55 },
  { id: "4", name: "StarDust_X", avatar: "/images/avatar-4.jpg", status: "away", level: 27 },
  { id: "5", name: "CyberWolf", avatar: "/images/avatar-5.jpg", status: "online", level: 31 },
  { id: "6", name: "QuantumFox", avatar: "/images/avatar-6.jpg", status: "offline", level: 44 },
  { id: "7", name: "BlazeTitan", avatar: "/images/avatar-7.jpg", status: "in-game", currentGame: "Iron Colossus", level: 61 },
  { id: "8", name: "VoidHunter", avatar: "/images/avatar-8.jpg", status: "online", level: 33 },
]

export const trophies: Trophy[] = [
  { id: "1", name: "First Blood", description: "Defeat your first enemy", rarity: "common", game: "Astral Horizon", earned: true, earnedDate: "2025-01-15", icon: "sword" },
  { id: "2", name: "World Explorer", description: "Discover all regions of the map", rarity: "rare", game: "Astral Horizon", earned: true, earnedDate: "2025-02-01", icon: "map" },
  { id: "3", name: "Speed Demon", description: "Complete a race in under 60 seconds", rarity: "ultra-rare", game: "Neon Drift", earned: true, earnedDate: "2025-01-20", icon: "zap" },
  { id: "4", name: "Untouchable", description: "Win 10 matches without dying", rarity: "legendary", game: "Velocity Strike", earned: false, icon: "shield" },
  { id: "5", name: "Master Strategist", description: "Win 100 ranked matches", rarity: "rare", game: "Velocity Strike", earned: true, earnedDate: "2025-02-10", icon: "trophy" },
  { id: "6", name: "Ghost Protocol", description: "Complete a mission without being detected", rarity: "uncommon", game: "Shadow Protocol", earned: true, earnedDate: "2025-02-20", icon: "eye" },
  { id: "7", name: "Cosmic Pioneer", description: "Discover 50 star systems", rarity: "rare", game: "Celestial Odyssey", earned: false, icon: "star" },
  { id: "8", name: "Iron Will", description: "Survive 100 waves in survival mode", rarity: "legendary", game: "Iron Colossus", earned: false, icon: "shield" },
]

export const lobbies: Lobby[] = [
  { id: "1", name: "Friday Night Raid", game: "Phantom Realms Online", host: "ShadowKnight_99", members: 4, maxMembers: 6, status: "waiting" },
  { id: "2", name: "Ranked Grind", game: "Velocity Strike", host: "PhantomBlade", members: 3, maxMembers: 5, status: "waiting" },
  { id: "3", name: "Chill Racing", game: "Neon Drift", host: "NeonRacer", members: 6, maxMembers: 8, status: "in-game" },
  { id: "4", name: "Boss Rush", game: "Astral Horizon", host: "BlazeTitan", members: 2, maxMembers: 4, status: "waiting" },
  { id: "5", name: "Mech Wars", game: "Iron Colossus", host: "CyberWolf", members: 4, maxMembers: 4, status: "full" },
]

export const userProfile = {
  name: "NexusPlayer",
  level: 47,
  xp: 7850,
  xpToNextLevel: 10000,
  totalTrophies: 342,
  platinumTrophies: 8,
  goldTrophies: 45,
  silverTrophies: 112,
  bronzeTrophies: 177,
  gamesOwned: 56,
  hoursPlayed: 1284,
  memberSince: "2019",
  psPlus: true,
  avatar: "/images/user-avatar.jpg",
  topGenres: ["Action RPG", "FPS", "Racing"],
  recentAchievement: "Speed Demon",
}
