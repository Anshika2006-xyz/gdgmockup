"use client"

import { motion } from "framer-motion"
import { Circle, Gamepad2, MessageSquare } from "lucide-react"
import Link from "next/link"
import { friends } from "@/lib/game-data"
import { cn } from "@/lib/utils"

const statusColors = {
  online: "bg-green-500",
  "in-game": "bg-primary",
  away: "bg-yellow-500",
  offline: "bg-muted-foreground/50",
}

const statusLabels = {
  online: "Online",
  "in-game": "In Game",
  away: "Away",
  offline: "Offline",
}

export function FriendActivity() {
  const onlineFriends = friends.filter((f) => f.status !== "offline")
  const offlineFriends = friends.filter((f) => f.status === "offline")

  return (
    <section>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-bold text-foreground">Friends</h2>
        <Link
          href="/social"
          className="text-xs font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          View All
        </Link>
      </div>
      <div className="rounded-xl border border-border/50 bg-card">
        <div className="p-3">
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Online - {onlineFriends.length}
          </p>
          <div className="flex flex-col gap-1">
            {onlineFriends.map((friend, i) => (
              <motion.div
                key={friend.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="group flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-secondary"
              >
                <div className="relative h-8 w-8 shrink-0 overflow-hidden rounded-full bg-secondary">
                  <div className="flex h-full w-full items-center justify-center text-xs font-bold text-foreground">
                    {friend.name.charAt(0)}
                  </div>
                  <span
                    className={cn(
                      "absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card",
                      statusColors[friend.status]
                    )}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-foreground">
                    {friend.name}
                  </p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    {friend.status === "in-game" ? (
                      <>
                        <Gamepad2 className="h-3 w-3 text-primary" />
                        <span className="text-primary">
                          {friend.currentGame}
                        </span>
                      </>
                    ) : (
                      statusLabels[friend.status]
                    )}
                  </p>
                </div>
                <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label={`Message ${friend.name}`}>
                    <MessageSquare className="h-3.5 w-3.5" />
                  </button>
                  {friend.status === "in-game" && (
                    <button className="flex h-7 items-center gap-1 rounded-md bg-primary/20 px-2 text-xs font-medium text-primary hover:bg-primary/30">
                      Join
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        {offlineFriends.length > 0 && (
          <div className="border-t border-border/50 p-3">
            <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Offline - {offlineFriends.length}
            </p>
            {offlineFriends.map((friend) => (
              <div
                key={friend.id}
                className="flex items-center gap-3 rounded-lg px-2 py-2 opacity-50"
              >
                <div className="relative h-8 w-8 shrink-0 overflow-hidden rounded-full bg-secondary">
                  <div className="flex h-full w-full items-center justify-center text-xs font-bold text-foreground">
                    {friend.name.charAt(0)}
                  </div>
                </div>
                <p className="truncate text-sm text-muted-foreground">
                  {friend.name}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
