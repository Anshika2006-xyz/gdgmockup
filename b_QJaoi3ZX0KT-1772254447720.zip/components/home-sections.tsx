"use client"

import { motion } from "framer-motion"
import { Play, ChevronRight, Clock, Trophy, Flame } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { games } from "@/lib/game-data"

const continuePlayingGames = games.filter((g) => g.progress)

export function HeroSection() {
  const featuredGame = games[0]

  return (
    <section className="relative overflow-hidden rounded-2xl">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.jpg"
          alt=""
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="relative flex min-h-[420px] flex-col justify-end p-6 lg:min-h-[480px] lg:p-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-lg"
        >
          <div className="mb-3 flex items-center gap-2">
            <span className="rounded-full bg-primary/20 px-3 py-1 text-xs font-medium text-primary">
              Featured
            </span>
            <span className="text-xs text-muted-foreground">
              {featuredGame.genre}
            </span>
          </div>
          <h1 className="mb-3 text-4xl font-bold tracking-tight text-foreground lg:text-5xl text-balance">
            {featuredGame.title}
          </h1>
          <p className="mb-6 text-sm leading-relaxed text-muted-foreground lg:text-base text-pretty">
            {featuredGame.description}
          </p>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 animate-glow">
              <Play className="h-4 w-4" fill="currentColor" />
              Continue Playing
            </button>
            <Link
              href="/store"
              className="flex items-center gap-1 rounded-xl border border-border px-5 py-3 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
            >
              View Details
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export function ContinuePlaying() {
  return (
    <section>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-foreground">
            Continue Playing
          </h2>
        </div>
        <Link
          href="/store"
          className="text-xs font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          View All
        </Link>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {continuePlayingGames.map((game, i) => (
          <motion.div
            key={game.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="group relative overflow-hidden rounded-xl border border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-[0_0_30px_-5px] hover:shadow-primary/20"
          >
            <div className="relative aspect-[16/9] overflow-hidden">
              <Image
                src={game.image}
                alt={game.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
              <button className="absolute left-1/2 top-1/2 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-primary/90 text-primary-foreground opacity-0 backdrop-blur-sm transition-opacity group-hover:opacity-100" aria-label={`Play ${game.title}`}>
                <Play className="h-5 w-5" fill="currentColor" />
              </button>
            </div>
            <div className="p-4">
              <div className="mb-1 flex items-center justify-between">
                <h3 className="font-semibold text-foreground">
                  {game.title}
                </h3>
                <span className="text-xs text-muted-foreground">
                  {game.lastPlayed}
                </span>
              </div>
              <p className="mb-3 text-xs text-muted-foreground">
                {game.genre}
              </p>
              {/* Progress Bar */}
              <div className="flex items-center gap-3">
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${game.progress}%` }}
                    transition={{ duration: 1, delay: 0.5 + i * 0.15 }}
                    className="h-full rounded-full bg-primary"
                  />
                </div>
                <span className="text-xs font-medium text-primary">
                  {game.progress}%
                </span>
              </div>
              {game.trophies && (
                <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                  <Trophy className="h-3 w-3 text-ps-gold" />
                  <span>
                    {game.trophies.earned}/{game.trophies.total} Trophies
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

export function TrendingSection() {
  const trendingGames = games.filter((g) => !g.progress).slice(0, 4)

  return (
    <section>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flame className="h-5 w-5 text-destructive" />
          <h2 className="text-lg font-bold text-foreground">Trending Now</h2>
        </div>
        <Link
          href="/store"
          className="text-xs font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          View All
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {trendingGames.map((game, i) => (
          <motion.div
            key={game.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="group relative overflow-hidden rounded-xl border border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-[0_0_30px_-5px] hover:shadow-primary/20"
          >
            <div className="relative aspect-[3/4] overflow-hidden">
              <Image
                src={game.image}
                alt={game.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <h3 className="text-sm font-semibold text-foreground">
                  {game.title}
                </h3>
                <p className="text-xs text-muted-foreground">{game.genre}</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs font-bold text-primary">
                    {game.price ? `$${game.price}` : "Free with PS Plus"}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-ps-gold">
                    {"*".repeat(Math.round(game.rating))}
                    <span className="text-muted-foreground ml-1">
                      {game.rating}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
