"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import {
  Search,
  Filter,
  Star,
  Sparkles,
  ShoppingCart,
  Heart,
  ChevronDown,
  Tag,
  Users,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { games } from "@/lib/game-data"
import { cn } from "@/lib/utils"

const genres = ["All", "Action RPG", "FPS", "Racing", "Story Adventure", "MMORPG", "Action", "Stealth", "Space Exploration"]

const aiRecommendations = [
  {
    reason: "Because you loved Astral Horizon",
    games: [games[3], games[6]],
  },
  {
    reason: "3 friends are playing",
    games: [games[1], games[4]],
  },
  {
    reason: "Trending in your region",
    games: [games[5], games[7]],
  },
]

export default function StorePage() {
  const [selectedGenre, setSelectedGenre] = useState("All")
  const [sortBy, setSortBy] = useState("popular")

  const filteredGames =
    selectedGenre === "All"
      ? games
      : games.filter((g) => g.genre === selectedGenre)

  return (
    <>
      <TopNav />
      <main className="mx-auto max-w-7xl px-4 pt-20 pb-12 lg:px-6">
        {/* AI Recommendation Banner */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-r from-primary/10 via-card to-primary/5"
        >
          <div className="p-6">
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
                <Sparkles className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">
                  AI Picks For You
                </h2>
                <p className="text-xs text-muted-foreground">
                  Personalized based on your play history
                </p>
              </div>
            </div>
            <div className="flex flex-col gap-6">
              {aiRecommendations.map((rec, i) => (
                <div key={i}>
                  <p className="mb-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
                    {i === 1 && <Users className="h-3 w-3 text-primary" />}
                    {rec.reason}
                  </p>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {rec.games.map((game) => (
                      <motion.div
                        key={game.id}
                        whileHover={{ scale: 1.02 }}
                        className="flex gap-3 rounded-xl border border-border/50 bg-card/80 p-3 transition-colors hover:border-primary/30"
                      >
                        <div className="relative h-20 w-16 shrink-0 overflow-hidden rounded-lg">
                          <Image
                            src={game.image}
                            alt={game.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="text-sm font-semibold text-foreground">
                            {game.title}
                          </h4>
                          <p className="text-xs text-muted-foreground">
                            {game.genre}
                          </p>
                          <div className="mt-1 flex items-center gap-1">
                            <Star className="h-3 w-3 fill-ps-gold text-ps-gold" />
                            <span className="text-xs text-foreground">
                              {game.rating}
                            </span>
                          </div>
                          <p className="mt-1 text-xs font-bold text-primary">
                            {game.price ? `$${game.price}` : "Free"}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* Store Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-2xl font-bold text-foreground">Game Store</h1>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-xl bg-secondary px-3 py-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search store..."
                className="w-40 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none sm:w-56"
              />
            </div>
            <div className="relative">
              <button className="flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground">
                <Filter className="h-4 w-4" />
                Sort
                <ChevronDown className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Genre Filters */}
        <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
          {genres.map((genre) => (
            <button
              key={genre}
              onClick={() => setSelectedGenre(genre)}
              className={cn(
                "shrink-0 rounded-full px-4 py-1.5 text-xs font-medium transition-all",
                selectedGenre === genre
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              )}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Game Grid */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence mode="wait">
            {filteredGames.map((game, i) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="group overflow-hidden rounded-xl border border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-[0_0_40px_-10px] hover:shadow-primary/20"
              >
                <div className="relative aspect-[3/4] overflow-hidden">
                  <Image
                    src={game.image}
                    alt={game.title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent opacity-60 transition-opacity group-hover:opacity-80" />

                  {/* Hover overlay */}
                  <div className="absolute inset-0 flex flex-col justify-end p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                    <div className="flex gap-2">
                      <button className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-primary py-2.5 text-xs font-semibold text-primary-foreground transition-colors hover:brightness-110">
                        <ShoppingCart className="h-3.5 w-3.5" />
                        {game.price ? `$${game.price}` : "Get Free"}
                      </button>
                      <button className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-card/80 text-muted-foreground backdrop-blur-sm transition-colors hover:text-destructive" aria-label={`Wishlist ${game.title}`}>
                        <Heart className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="absolute left-3 top-3 flex flex-wrap gap-1">
                    {!game.price && (
                      <span className="rounded-md bg-primary/90 px-2 py-0.5 text-[10px] font-bold text-primary-foreground backdrop-blur-sm">
                        FREE
                      </span>
                    )}
                    {game.rating >= 4.7 && (
                      <span className="rounded-md bg-ps-gold/90 px-2 py-0.5 text-[10px] font-bold text-background backdrop-blur-sm">
                        TOP RATED
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="text-sm font-bold text-foreground">
                    {game.title}
                  </h3>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">
                      {game.genre}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {game.releaseYear}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-ps-gold text-ps-gold" />
                      <span className="text-xs font-medium text-foreground">
                        {game.rating}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-primary">
                      {game.price ? `$${game.price}` : "Free"}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {game.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground"
                      >
                        <Tag className="h-2.5 w-2.5" />
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </main>
    </>
  )
}
