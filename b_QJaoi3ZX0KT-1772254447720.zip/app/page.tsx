import { TopNav } from "@/components/top-nav"
import {
  HeroSection,
  ContinuePlaying,
  TrendingSection,
} from "@/components/home-sections"
import { FriendActivity } from "@/components/friend-activity"

export default function Home() {
  return (
    <>
      <TopNav />
      <main className="mx-auto max-w-7xl px-4 pt-20 pb-12 lg:px-6">
        <div className="flex flex-col gap-8 lg:flex-row">
          {/* Main Content */}
          <div className="flex flex-1 flex-col gap-8">
            <HeroSection />
            <ContinuePlaying />
            <TrendingSection />
          </div>
          {/* Sidebar - Friends */}
          <aside className="w-full lg:w-72 xl:w-80">
            <div className="lg:sticky lg:top-20">
              <FriendActivity />
            </div>
          </aside>
        </div>
      </main>
    </>
  )
}
