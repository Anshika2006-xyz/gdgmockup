"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import {
  Sparkles,
  Send,
  Star,
  Gamepad2,
  Heart,
  Zap,
  Swords,
  Compass,
  Bot,
  User,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { games } from "@/lib/game-data"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  role: "user" | "ai"
  content: string
  recommendations?: typeof games
}

const moodPrompts = [
  { label: "Something epic", icon: Swords, query: "I want something epic with huge battles and a grand story" },
  { label: "Quick & competitive", icon: Zap, query: "I want something fast-paced and competitive to play online" },
  { label: "Chill exploration", icon: Compass, query: "I want to relax and explore a beautiful world" },
  { label: "Story-driven", icon: Heart, query: "I want a game with an amazing emotional story" },
]

function getAIResponse(input: string): Message {
  const lower = input.toLowerCase()
  let content: string
  let recs: typeof games = []

  if (lower.includes("epic") || lower.includes("battle") || lower.includes("grand")) {
    content = "For an epic experience with massive scale, I would recommend these titles based on your gaming history. You tend to gravitate towards action RPGs with rich lore - these should hit the mark perfectly."
    recs = [games[0], games[5], games[3]]
  } else if (lower.includes("fast") || lower.includes("compet") || lower.includes("online") || lower.includes("fps")) {
    content = "You are looking for some adrenaline! Based on your Velocity Strike playtime and competitive ranking, here are games that match your skill level and preferred pace."
    recs = [games[1], games[2], games[5]]
  } else if (lower.includes("chill") || lower.includes("relax") || lower.includes("explore") || lower.includes("beautiful")) {
    content = "Time to unwind! These open-world experiences offer breathtaking exploration without pressure. Your play patterns show you spend 40% more time exploring than the average player - you will love these."
    recs = [games[7], games[0], games[4]]
  } else if (lower.includes("story") || lower.includes("emotional") || lower.includes("narrative")) {
    content = "A fellow story enthusiast! Given that you completed Astral Horizon's entire narrative and spent extra time on side quests, these narrative-rich games will keep you hooked for hours."
    recs = [games[3], games[6], games[0]]
  } else if (lower.includes("free") || lower.includes("cheap") || lower.includes("budget")) {
    content = "Great picks available without breaking the bank! These free-to-play and discounted titles offer incredible value. PS Plus members get additional perks on all of these."
    recs = games.filter((g) => !g.price || (g.price && g.price < 50)).slice(0, 3)
  } else {
    content = "Based on your overall gaming profile, play history, and what your friends are enjoying, here are my top picks for you right now. Each offers something unique that matches your tastes."
    recs = [games[0], games[3], games[7]]
  }

  return {
    id: Date.now().toString(),
    role: "ai",
    content,
    recommendations: recs,
  }
}

export default function DiscoverPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "ai",
      content:
        "Welcome to AI Discover! I analyze your play history, trophy collection, and gaming preferences to find your next favorite game. What kind of experience are you looking for today?",
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSend = (text?: string) => {
    const msg = text || input
    if (!msg.trim()) return

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: msg,
    }

    setMessages((prev) => [...prev, userMsg])
    setInput("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMsg = getAIResponse(msg)
      setMessages((prev) => [...prev, aiMsg])
      setIsTyping(false)
    }, 1200)
  }

  return (
    <>
      <TopNav />
      <main className="mx-auto flex h-[calc(100vh-4rem)] max-w-4xl flex-col px-4 pt-20 pb-4 lg:px-6">
        {/* Header */}
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/20">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">AI Discover</h1>
            <p className="text-xs text-muted-foreground">
              Your personal gaming concierge powered by AI
            </p>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto rounded-xl border border-border/50 bg-card/50 p-4">
          <div className="flex flex-col gap-4">
            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex gap-3",
                    msg.role === "user" ? "flex-row-reverse" : ""
                  )}
                >
                  <div
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                      msg.role === "ai"
                        ? "bg-primary/20"
                        : "bg-secondary"
                    )}
                  >
                    {msg.role === "ai" ? (
                      <Bot className="h-4 w-4 text-primary" />
                    ) : (
                      <User className="h-4 w-4 text-foreground" />
                    )}
                  </div>
                  <div
                    className={cn(
                      "max-w-[80%] rounded-xl p-4",
                      msg.role === "ai"
                        ? "bg-secondary/70"
                        : "bg-primary/20"
                    )}
                  >
                    <p className="text-sm leading-relaxed text-foreground">
                      {msg.content}
                    </p>

                    {/* Game Recommendations */}
                    {msg.recommendations && (
                      <div className="mt-4 flex flex-col gap-3">
                        {msg.recommendations.map((game) => (
                          <motion.div
                            key={game.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            whileHover={{ scale: 1.01 }}
                            className="flex gap-3 rounded-xl border border-border/50 bg-card p-3 transition-colors hover:border-primary/30"
                          >
                            <div className="relative h-16 w-12 shrink-0 overflow-hidden rounded-lg">
                              <Image
                                src={game.image}
                                alt={game.title}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <h4 className="text-sm font-semibold text-foreground">
                                {game.title}
                              </h4>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span>{game.genre}</span>
                                <span className="flex items-center gap-0.5">
                                  <Star className="h-3 w-3 fill-ps-gold text-ps-gold" />
                                  {game.rating}
                                </span>
                              </div>
                              <p className="mt-0.5 text-xs font-bold text-primary">
                                {game.price ? `$${game.price}` : "Free with PS Plus"}
                              </p>
                            </div>
                            <button className="flex h-8 shrink-0 items-center gap-1 self-center rounded-lg bg-primary/20 px-3 text-xs font-medium text-primary transition-colors hover:bg-primary/30">
                              <Gamepad2 className="h-3 w-3" />
                              View
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing indicator */}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/20">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="flex items-center gap-1 rounded-xl bg-secondary/70 px-4 py-3">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:0ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:300ms]" />
                </div>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Mood Prompts */}
        {messages.length <= 1 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4"
          >
            {moodPrompts.map((prompt) => (
              <button
                key={prompt.label}
                onClick={() => handleSend(prompt.query)}
                className="flex items-center gap-2 rounded-xl border border-border/50 bg-card px-3 py-3 text-xs font-medium text-foreground transition-all hover:border-primary/30 hover:bg-primary/5"
              >
                <prompt.icon className="h-4 w-4 text-primary" />
                {prompt.label}
              </button>
            ))}
          </motion.div>
        )}

        {/* Input */}
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-border/50 bg-card p-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend()
            }}
            placeholder="Ask me anything about games..."
            className="flex-1 bg-transparent px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isTyping}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-all disabled:opacity-50 hover:brightness-110"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </main>
    </>
  )
}
