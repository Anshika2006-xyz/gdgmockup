"use client"

import { motion } from "framer-motion"
import {
  Trophy,
  Star,
  Clock,
  Gamepad2,
  Shield,
  Sword,
  Map,
  Zap,
  Eye,
  Target,
  Award,
  TrendingUp,
  Calendar,
} from "lucide-react"
import Image from "next/image"
import { TopNav } from "@/components/top-nav"
import { userProfile, trophies, games } from "@/lib/game-data"
import { cn } from "@/lib/utils"

const trophyIcons: Record<string, React.ElementType> = {
  sword: Sword,
  map: Map,
  zap: Zap,
  shield: Shield,
  trophy: Trophy,
  eye: Eye,
  star: Star,
  target: Target,
}

const rarityConfig = {
  common: { color: "text-muted-foreground", bg: "bg-muted", label: "Common" },
  uncommon: { color: "text-green-400", bg: "bg-green-500/10", label: "Uncommon" },
  rare: { color: "text-primary", bg: "bg-primary/10", label: "Rare" },
  "ultra-rare": { color: "text-ps-neon", bg: "bg-ps-neon/10", label: "Ultra Rare" },
  legendary: { color: "text-ps-gold", bg: "bg-ps-gold/10", label: "Legendary" },
}

export default function ProfilePage() {
  const xpPercent = (userProfile.xp / userProfile.xpToNextLevel) * 100

  return (
    <>
      <TopNav />
      <main className="mx-auto max-w-7xl px-4 pt-20 pb-12 lg:px-6">
        {/* Profile Header */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 overflow-hidden rounded-2xl border border-border/50 bg-card"
        >
          {/* Banner */}
          <div className="relative h-32 overflow-hidden bg-gradient-to-r from-primary/30 via-primary/10 to-ps-neon/20 sm:h-44">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,transparent_0%,var(--card)_100%)] opacity-60" />
          </div>

          <div className="relative px-6 pb-6">
            {/* Avatar */}
            <div className="-mt-12 mb-4 flex flex-col gap-4 sm:-mt-14 sm:flex-row sm:items-end sm:justify-between">
              <div className="flex items-end gap-4">
                <div className="relative h-24 w-24 overflow-hidden rounded-2xl border-4 border-card shadow-xl sm:h-28 sm:w-28">
                  <Image
                    src={userProfile.avatar}
                    alt={userProfile.name}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-1 right-1 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {userProfile.level}
                  </div>
                </div>
                <div className="pb-1">
                  <h1 className="text-2xl font-bold text-foreground">
                    {userProfile.name}
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Member since {userProfile.memberSince}
                  </p>
                  {userProfile.psPlus && (
                    <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-ps-gold/10 px-3 py-0.5 text-xs font-medium text-ps-gold">
                      <Star className="h-3 w-3 fill-ps-gold" />
                      PS Plus Premium
                    </span>
                  )}
                </div>
              </div>
              <button className="rounded-xl border border-border px-5 py-2 text-sm font-medium text-foreground transition-colors hover:bg-secondary">
                Edit Profile
              </button>
            </div>

            {/* XP Bar */}
            <div className="mb-6">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="font-medium text-foreground">
                  Level {userProfile.level}
                </span>
                <span className="text-muted-foreground">
                  {userProfile.xp.toLocaleString()} / {userProfile.xpToNextLevel.toLocaleString()} XP
                </span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-secondary">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${xpPercent}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-to-r from-primary to-ps-neon"
                />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {(userProfile.xpToNextLevel - userProfile.xp).toLocaleString()} XP to Level {userProfile.level + 1}
              </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: "Total Trophies", value: userProfile.totalTrophies, icon: Trophy, color: "text-ps-gold" },
                { label: "Games Owned", value: userProfile.gamesOwned, icon: Gamepad2, color: "text-primary" },
                { label: "Hours Played", value: `${userProfile.hoursPlayed}h`, icon: Clock, color: "text-ps-neon" },
                { label: "Platinum", value: userProfile.platinumTrophies, icon: Award, color: "text-foreground" },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="rounded-xl border border-border/50 bg-secondary/50 p-4 text-center"
                >
                  <stat.icon className={cn("mx-auto mb-2 h-5 w-5", stat.color)} />
                  <p className="text-xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Trophy Showcase */}
          <div className="lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-ps-gold" />
                <h2 className="text-lg font-bold text-foreground">
                  Trophy Showcase
                </h2>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-ps-gold" />
                  {userProfile.goldTrophies} Gold
                </span>
                <span className="flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-muted-foreground" />
                  {userProfile.silverTrophies} Silver
                </span>
                <span className="flex items-center gap-1">
                  <div className="h-2 w-2 rounded-full bg-amber-700" />
                  {userProfile.bronzeTrophies} Bronze
                </span>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {trophies.map((trophy, i) => {
                const rarity = rarityConfig[trophy.rarity]
                const IconComp = trophyIcons[trophy.icon] || Trophy
                return (
                  <motion.div
                    key={trophy.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className={cn(
                      "relative overflow-hidden rounded-xl border bg-card p-4 transition-all",
                      trophy.earned
                        ? "border-border/50 hover:border-primary/30 hover:shadow-[0_0_20px_-5px] hover:shadow-primary/20"
                        : "border-border/30 opacity-60"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                          rarity.bg
                        )}
                      >
                        <IconComp className={cn("h-5 w-5", rarity.color)} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-semibold text-foreground">
                            {trophy.name}
                          </h3>
                          {!trophy.earned && (
                            <span className="rounded bg-secondary px-1.5 py-0.5 text-[9px] font-medium text-muted-foreground">
                              LOCKED
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {trophy.description}
                        </p>
                        <div className="mt-1.5 flex items-center gap-2">
                          <span
                            className={cn(
                              "rounded-full px-2 py-0.5 text-[10px] font-medium",
                              rarity.bg,
                              rarity.color
                            )}
                          >
                            {rarity.label}
                          </span>
                          <span className="text-[10px] text-muted-foreground">
                            {trophy.game}
                          </span>
                        </div>
                        {trophy.earnedDate && (
                          <p className="mt-1 flex items-center gap-1 text-[10px] text-muted-foreground">
                            <Calendar className="h-2.5 w-2.5" />
                            {trophy.earnedDate}
                          </p>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>

          {/* Sidebar */}
          <div className="flex flex-col gap-6">
            {/* Top Genres */}
            <div className="rounded-xl border border-border/50 bg-card p-5">
              <div className="mb-3 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                <h3 className="text-sm font-bold text-foreground">
                  Top Genres
                </h3>
              </div>
              <div className="flex flex-col gap-2">
                {userProfile.topGenres.map((genre, i) => (
                  <div
                    key={genre}
                    className="flex items-center justify-between rounded-lg bg-secondary/50 px-3 py-2"
                  >
                    <span className="text-sm text-foreground">{genre}</span>
                    <span className="text-xs font-medium text-primary">
                      #{i + 1}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Games */}
            <div className="rounded-xl border border-border/50 bg-card p-5">
              <h3 className="mb-3 text-sm font-bold text-foreground">
                Recently Played
              </h3>
              <div className="flex flex-col gap-3">
                {games
                  .filter((g) => g.progress)
                  .map((game) => (
                    <div
                      key={game.id}
                      className="flex items-center gap-3"
                    >
                      <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg">
                        <Image
                          src={game.image}
                          alt={game.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-foreground">
                          {game.title}
                        </p>
                        <div className="mt-0.5 flex items-center gap-2">
                          <div className="h-1 flex-1 overflow-hidden rounded-full bg-secondary">
                            <div
                              className="h-full rounded-full bg-primary"
                              style={{ width: `${game.progress}%` }}
                            />
                          </div>
                          <span className="text-[10px] text-muted-foreground">
                            {game.progress}%
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Gaming Summary */}
            <div className="overflow-hidden rounded-xl border border-primary/30 bg-gradient-to-b from-primary/10 to-card p-5">
              <div className="mb-2 flex items-center gap-2">
                <Star className="h-4 w-4 text-ps-gold" />
                <h3 className="text-sm font-bold text-foreground">
                  AI Gaming Summary
                </h3>
              </div>
              <p className="text-xs leading-relaxed text-muted-foreground">
                You are a dedicated action RPG player with a strong competitive
                streak. Your play patterns suggest you enjoy deep narratives and
                challenging boss encounters. You have earned{" "}
                <span className="font-medium text-foreground">
                  {userProfile.totalTrophies} trophies
                </span>{" "}
                across{" "}
                <span className="font-medium text-foreground">
                  {userProfile.gamesOwned} games
                </span>{" "}
                with{" "}
                <span className="font-medium text-foreground">
                  {userProfile.hoursPlayed} hours
                </span>{" "}
                of total playtime. Your next milestone: Level{" "}
                {userProfile.level + 1} is within reach!
              </p>
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
