"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Users,
  Gamepad2,
  MessageSquare,
  Plus,
  Crown,
  Circle,
  Mic,
  MicOff,
  UserPlus,
  LogIn,
  Radio,
} from "lucide-react"
import { TopNav } from "@/components/top-nav"
import { friends, lobbies } from "@/lib/game-data"
import { cn } from "@/lib/utils"

const statusColors = {
  online: "bg-green-500",
  "in-game": "bg-primary",
  away: "bg-yellow-500",
  offline: "bg-muted-foreground/50",
}

const lobbyStatusConfig = {
  waiting: { color: "text-green-500", bg: "bg-green-500/10", label: "Waiting for players" },
  "in-game": { color: "text-primary", bg: "bg-primary/10", label: "In Progress" },
  full: { color: "text-destructive", bg: "bg-destructive/10", label: "Full" },
}

const activityFeed = [
  { user: "ShadowKnight_99", action: "earned trophy", detail: "World Explorer in Astral Horizon", time: "2m ago" },
  { user: "PhantomBlade", action: "started playing", detail: "Velocity Strike", time: "5m ago" },
  { user: "NeonRacer", action: "created lobby", detail: "Chill Racing", time: "12m ago" },
  { user: "BlazeTitan", action: "earned platinum", detail: "Iron Colossus", time: "1h ago" },
  { user: "CyberWolf", action: "joined lobby", detail: "Mech Wars", time: "1h ago" },
]

export default function SocialPage() {
  const [activeTab, setActiveTab] = useState<"friends" | "lobbies" | "feed">("lobbies")

  return (
    <>
      <TopNav />
      <main className="mx-auto max-w-7xl px-4 pt-20 pb-12 lg:px-6">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Social Hub</h1>
            <p className="text-sm text-muted-foreground">
              Connect, chat, and play together
            </p>
          </div>
          <button className="flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110">
            <Plus className="h-4 w-4" />
            Create Lobby
          </button>
        </div>

        {/* Tabs */}
        <div className="mb-6 flex gap-1 rounded-xl bg-secondary p-1">
          {[
            { id: "lobbies" as const, label: "Game Lobbies", icon: Gamepad2 },
            { id: "friends" as const, label: "Friends", icon: Users },
            { id: "feed" as const, label: "Activity Feed", icon: Radio },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all",
                activeTab === tab.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="h-4 w-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Lobbies Tab */}
        {activeTab === "lobbies" && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-4"
          >
            {lobbies.map((lobby, i) => {
              const statusConf = lobbyStatusConfig[lobby.status]
              return (
                <motion.div
                  key={lobby.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="group overflow-hidden rounded-xl border border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-[0_0_30px_-5px] hover:shadow-primary/20"
                >
                  <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                        <Gamepad2 className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-bold text-foreground">
                            {lobby.name}
                          </h3>
                          <span
                            className={cn(
                              "rounded-full px-2 py-0.5 text-[10px] font-medium",
                              statusConf.bg,
                              statusConf.color
                            )}
                          >
                            {statusConf.label}
                          </span>
                        </div>
                        <p className="mt-0.5 text-sm text-muted-foreground">
                          {lobby.game}
                        </p>
                        <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Crown className="h-3 w-3 text-ps-gold" />
                            {lobby.host}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {lobby.members}/{lobby.maxMembers}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {lobby.status === "waiting" && (
                        <button className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110">
                          <LogIn className="h-4 w-4" />
                          Join Lobby
                        </button>
                      )}
                      {lobby.status === "in-game" && (
                        <button className="flex items-center gap-2 rounded-lg border border-primary/50 bg-primary/10 px-5 py-2 text-sm font-medium text-primary transition-all hover:bg-primary/20">
                          <Mic className="h-4 w-4" />
                          Spectate
                        </button>
                      )}
                      {lobby.status === "full" && (
                        <span className="rounded-lg bg-secondary px-4 py-2 text-sm text-muted-foreground">
                          Lobby Full
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Members bar */}
                  <div className="border-t border-border/30 bg-secondary/30 px-5 py-3">
                    <div className="flex items-center justify-between">
                      <div className="flex -space-x-2">
                        {Array.from({ length: lobby.members }).map((_, j) => (
                          <div
                            key={j}
                            className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-card bg-secondary text-[10px] font-bold text-foreground"
                          >
                            {String.fromCharCode(65 + j)}
                          </div>
                        ))}
                        {lobby.members < lobby.maxMembers && (
                          <div className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-card bg-primary/10 text-primary">
                            <Plus className="h-3 w-3" />
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label="Voice chat">
                          <Mic className="h-3.5 w-3.5" />
                        </button>
                        <button className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label="Text chat">
                          <MessageSquare className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        )}

        {/* Friends Tab */}
        {activeTab === "friends" && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {friends.filter((f) => f.status !== "offline").length} online
              </p>
              <button className="flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-xs font-medium text-foreground transition-colors hover:bg-secondary/80">
                <UserPlus className="h-3.5 w-3.5" />
                Add Friend
              </button>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {friends.map((friend, i) => (
                <motion.div
                  key={friend.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-3 rounded-xl border border-border/50 bg-card p-4 transition-all hover:border-primary/30"
                >
                  <div className="relative">
                    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-sm font-bold text-foreground">
                      {friend.name.charAt(0)}
                    </div>
                    <span
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card",
                        statusColors[friend.status]
                      )}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">
                      {friend.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Level {friend.level}
                    </p>
                    {friend.currentGame && (
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-primary">
                        <Gamepad2 className="h-3 w-3" />
                        {friend.currentGame}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col gap-1">
                    <button className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground" aria-label={`Message ${friend.name}`}>
                      <MessageSquare className="h-4 w-4" />
                    </button>
                    {friend.status === "in-game" && (
                      <button className="rounded-md bg-primary/20 px-2 py-1 text-[10px] font-medium text-primary hover:bg-primary/30">
                        Join
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Activity Feed Tab */}
        {activeTab === "feed" && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-3"
          >
            {activityFeed.map((activity, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="flex items-start gap-3 rounded-xl border border-border/50 bg-card p-4 transition-all hover:border-primary/20"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-bold text-foreground">
                  {activity.user.charAt(0)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-foreground">
                    <span className="font-semibold">{activity.user}</span>{" "}
                    <span className="text-muted-foreground">{activity.action}</span>
                  </p>
                  <p className="text-xs font-medium text-primary">
                    {activity.detail}
                  </p>
                </div>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {activity.time}
                </span>
              </motion.div>
            ))}
          </motion.div>
        )}
      </main>
    </>
  )
}
